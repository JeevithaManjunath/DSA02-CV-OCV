Place your road video here, e.g. data/road.mp4.
For camera calibration, create data/calibration/ and place chessboard images there.
For a dedicated traffic-sign detector, place its YOLO .pt file in models/ and set sign_model in config.yaml.
