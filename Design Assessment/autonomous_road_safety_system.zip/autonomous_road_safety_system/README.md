# Computer Vision Based Autonomous Road Safety System

This project implements a modular road-safety pipeline integrating:

1. Camera calibration and image undistortion
2. Vehicle and pedestrian detection using YOLO
3. Road-sign recognition
4. Road-marking / lane detection
5. Multi-object tracking with a lightweight IoU tracker
6. Occlusion-aware track handling
7. Performance evaluation: precision, recall, F1, FPS, latency, tracking metrics
8. Environmental-condition analysis
9. CSV reporting and annotated video output

## Folder structure

```text
autonomous_road_safety_system/
├── src/
│   ├── main.py
│   ├── calibration.py
│   ├── detector.py
│   ├── tracker.py
│   ├── lane_detection.py
│   ├── sign_recognition.py
│   ├── occlusion.py
│   └── evaluation.py
├── models/
├── data/
├── outputs/
├── requirements.txt
├── config.yaml
└── README.md
```

## Installation

```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
```

The detector uses Ultralytics YOLO. On first execution, the selected pretrained model can be downloaded automatically if internet/model access is available.

## Run on a video

```bash
python src/main.py --source data/road.mp4 --output outputs/result.mp4
```

For a webcam:

```bash
python src/main.py --source 0 --output outputs/webcam_result.mp4
```

## Camera calibration

Put chessboard images in `data/calibration/` and run:

```bash
python src/calibration.py --images data/calibration --output data/camera_params.npz
```

Then set `camera_params` in `config.yaml`.

## Evaluation

For a simple benchmark from the generated CSV:

```bash
python src/evaluation.py --csv outputs/metrics.csv
```

For detection ground-truth comparison, prepare a CSV with:
`frame,gt_count,pred_count,tp,fp,fn`.

## Notes

- COCO-pretrained YOLO detects common road objects such as person, bicycle, car, motorcycle, bus and truck.
- A dedicated traffic-sign model can be supplied through `sign_model` in `config.yaml`.
- Lane/road-marking detection uses Canny + ROI + Hough lines as a transparent baseline.
- The included tracker is an educational baseline, not a replacement for DeepSORT/ByteTrack/BoT-SORT.
- For academic evaluation, report results separately for daylight/night, clear/rain/fog and low/medium/high traffic.
