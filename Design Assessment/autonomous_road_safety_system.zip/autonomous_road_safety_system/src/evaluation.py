import argparse
import pandas as pd
import numpy as np

def detection_metrics(df):
    tp, fp, fn = df["tp"].sum(), df["fp"].sum(), df["fn"].sum()
    precision = tp / (tp + fp) if tp + fp else 0
    recall = tp / (tp + fn) if tp + fn else 0
    f1 = 2*precision*recall/(precision+recall) if precision+recall else 0
    return precision, recall, f1

def summarize(csv_path):
    df = pd.read_csv(csv_path)
    print("Frames:", len(df))
    if {"tp","fp","fn"}.issubset(df.columns):
        p, r, f1 = detection_metrics(df)
        print(f"Precision: {p:.4f}")
        print(f"Recall:    {r:.4f}")
        print(f"F1-score:  {f1:.4f}")
    if "latency_ms" in df:
        print(f"Mean latency: {df.latency_ms.mean():.2f} ms")
        print(f"Approx FPS:   {1000/df.latency_ms.mean():.2f}")
    if "active_tracks" in df:
        print(f"Mean active tracks: {df.active_tracks.mean():.2f}")
    if "occluded_tracks" in df:
        print(f"Mean occluded tracks: {df.occluded_tracks.mean():.2f}")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True)
    args = p.parse_args()
    summarize(args.csv)
