import math

def iou(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    x1, y1 = max(ax1, bx1), max(ay1, by1)
    x2, y2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0, x2-x1) * max(0, y2-y1)
    area_a = max(0, ax2-ax1) * max(0, ay2-ay1)
    area_b = max(0, bx2-bx1) * max(0, by2-by1)
    union = area_a + area_b - inter
    return inter / union if union else 0.0

class IoUTracker:
    """Simple class-aware IoU tracker with missed-frame tolerance."""
    def __init__(self, iou_threshold=0.30, max_missed=12):
        self.iou_threshold = iou_threshold
        self.max_missed = max_missed
        self.next_id = 1
        self.tracks = {}

    def update(self, detections):
        unmatched = set(range(len(detections)))
        assigned = set()

        candidates = []
        for tid, t in self.tracks.items():
            for i, d in enumerate(detections):
                if d["class_id"] == t["class_id"]:
                    candidates.append((iou(t["bbox"], d["bbox"]), tid, i))
        candidates.sort(reverse=True)

        for score, tid, i in candidates:
            if score < self.iou_threshold or i not in unmatched or tid in assigned:
                continue
            d = detections[i]
            self.tracks[tid].update({
                "bbox": d["bbox"],
                "confidence": d["confidence"],
                "class_id": d["class_id"],
                "label": d["label"],
                "missed": 0,
                "occluded": False
            })
            unmatched.remove(i)
            assigned.add(tid)

        for tid, t in list(self.tracks.items()):
            if tid not in assigned:
                t["missed"] += 1
                t["occluded"] = t["missed"] > 0
                if t["missed"] > self.max_missed:
                    del self.tracks[tid]

        for i in unmatched:
            d = detections[i]
            tid = self.next_id
            self.next_id += 1
            self.tracks[tid] = {
                "bbox": d["bbox"],
                "confidence": d["confidence"],
                "class_id": d["class_id"],
                "label": d["label"],
                "missed": 0,
                "occluded": False
            }

        return [{"track_id": tid, **t} for tid, t in self.tracks.items()]
