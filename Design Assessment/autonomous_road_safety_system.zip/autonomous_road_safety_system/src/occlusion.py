def overlap_ratio(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    x1, y1 = max(ax1, bx1), max(ay1, by1)
    x2, y2 = min(ax2, by2), min(ay2, by2)
    if x2 <= x1 or y2 <= y1:
        return 0.0
    inter = (x2-x1) * (y2-y1)
    area_a = max(1, (ax2-ax1) * (ay2-ay1))
    return inter / area_a

def mark_occlusions(tracks, threshold=0.35):
    for i in range(len(tracks)):
        for j in range(i+1, len(tracks)):
            r1 = overlap_ratio(tracks[i]["bbox"], tracks[j]["bbox"])
            r2 = overlap_ratio(tracks[j]["bbox"], tracks[i]["bbox"])
            if max(r1, r2) >= threshold:
                tracks[i]["occluded"] = True
                tracks[j]["occluded"] = True
    return tracks
