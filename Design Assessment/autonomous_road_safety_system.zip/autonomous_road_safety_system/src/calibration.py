import argparse
import glob
import cv2
import numpy as np
from pathlib import Path

def calibrate(image_dir, output_file, rows=6, cols=9, square_size=1.0):
    paths = sorted(glob.glob(str(Path(image_dir) / "*.*")))
    objp = np.zeros((rows * cols, 3), np.float32)
    objp[:, :2] = np.mgrid[0:cols, 0:rows].T.reshape(-1, 2) * square_size

    objpoints, imgpoints = [], []
    image_size = None

    for path in paths:
        img = cv2.imread(path)
        if img is None:
            continue
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        image_size = gray.shape[::-1]
        ok, corners = cv2.findChessboardCorners(gray, (cols, rows), None)
        if ok:
            corners2 = cv2.cornerSubPix(
                gray, corners, (11, 11), (-1, -1),
                (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
            )
            objpoints.append(objp)
            imgpoints.append(corners2)

    if not objpoints:
        raise RuntimeError("No chessboard corners found. Check images and board dimensions.")

    rms, camera_matrix, dist_coeffs, _, _ = cv2.calibrateCamera(
        objpoints, imgpoints, image_size, None, None
    )
    np.savez(output_file, camera_matrix=camera_matrix, dist_coeffs=dist_coeffs, rms=rms)
    print(f"Calibration saved to {output_file}; RMS error={rms:.4f}")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--images", required=True)
    p.add_argument("--output", default="data/camera_params.npz")
    p.add_argument("--rows", type=int, default=6)
    p.add_argument("--cols", type=int, default=9)
    p.add_argument("--square-size", type=float, default=1.0)
    args = p.parse_args()
    calibrate(args.images, args.output, args.rows, args.cols, args.square_size)
