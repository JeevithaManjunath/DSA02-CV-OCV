from ultralytics import YOLO

class ObjectDetector:
    def __init__(self, model_path="yolov8n.pt", confidence=0.35, iou=0.50, device="cpu", classes=None):
        self.model = YOLO(model_path)
        self.confidence = confidence
        self.iou = iou
        self.device = device
        self.classes = classes

    def detect(self, frame):
        results = self.model.predict(
            source=frame,
            conf=self.confidence,
            iou=self.iou,
            device=self.device,
            verbose=False
        )
        detections = []
        if not results:
            return detections
        result = results[0]
        names = result.names
        if result.boxes is None:
            return detections

        for box in result.boxes:
            xyxy = box.xyxy[0].cpu().numpy().astype(int).tolist()
            conf = float(box.conf[0].cpu())
            cls_id = int(box.cls[0].cpu())
            label = names.get(cls_id, str(cls_id))
            if self.classes is not None and cls_id not in self.classes:
                continue
            detections.append({
                "bbox": xyxy,
                "confidence": conf,
                "class_id": cls_id,
                "label": label
            })
        return detections
