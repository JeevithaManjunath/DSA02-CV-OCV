import os
from ultralytics import YOLO

class SignRecognizer:
    """
    Optional dedicated traffic-sign model.
    Supply a trained YOLO sign model path in config.yaml.
    """
    def __init__(self, model_path="", confidence=0.35, device="cpu"):
        self.enabled = bool(model_path and os.path.exists(model_path))
        self.confidence = confidence
        self.device = device
        self.model = YOLO(model_path) if self.enabled else None

    def detect(self, frame):
        if not self.enabled:
            return []
        results = self.model.predict(source=frame, conf=self.confidence,
                                     device=self.device, verbose=False)
        out = []
        if not results:
            return out
        r = results[0]
        for box in r.boxes:
            xyxy = box.xyxy[0].cpu().numpy().astype(int).tolist()
            out.append({
                "bbox": xyxy,
                "confidence": float(box.conf[0].cpu()),
                "label": r.names[int(box.cls[0].cpu())]
            })
        return out
