import argparse
import csv
import time
import cv2
import numpy as np
import yaml
from pathlib import Path

from detector import ObjectDetector
from tracker import IoUTracker
from occlusion import mark_occlusions
from lane_detection import detect_road_markings
from sign_recognition import SignRecognizer

def load_calibration(path):
    if not path:
        return None
    p = Path(path)
    if not p.exists():
        print(f"Warning: calibration file not found: {p}")
        return None
    d = np.load(str(p))
    return d["camera_matrix"], d["dist_coeffs"]

def undistort(frame, calib):
    if calib is None:
        return frame
    camera_matrix, dist = calib
    h, w = frame.shape[:2]
    new_mtx, _ = cv2.getOptimalNewCameraMatrix(camera_matrix, dist, (w,h), 1, (w,h))
    return cv2.undistort(frame, camera_matrix, dist, None, new_mtx)

def draw_detection(frame, d, color=(0,255,0), prefix=""):
    x1,y1,x2,y2 = d["bbox"]
    text = f'{prefix}{d.get("label","obj")} {d.get("confidence",0):.2f}'
    cv2.rectangle(frame, (x1,y1), (x2,y2), color, 2)
    cv2.putText(frame, text, (x1, max(20,y1-7)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source", required=True, help="video path or webcam index")
    p.add_argument("--output", default="outputs/result.mp4")
    p.add_argument("--config", default="config.yaml")
    args = p.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    class_ids = list((cfg.get("classes") or {}).values())
    detector = ObjectDetector(cfg["model"], cfg["confidence"], cfg["iou"],
                              cfg.get("device","cpu"), class_ids)
    tracker = IoUTracker(cfg["tracker"]["iou_threshold"], cfg["tracker"]["max_missed"])
    sign_rec = SignRecognizer(cfg.get("sign_model",""), cfg["confidence"], cfg.get("device","cpu"))
    calib = load_calibration(cfg.get("camera_params",""))

    source = int(args.source) if str(args.source).isdigit() else args.source
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open source: {args.source}")

    fps_in = cap.get(cv2.CAP_PROP_FPS) or 25
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1280)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 720)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(args.output, cv2.VideoWriter_fourcc(*"mp4v"),
                             fps_in, (width, height))

    csv_path = str(Path(args.output).with_suffix(".csv"))
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        log = csv.writer(f)
        log.writerow(["frame","latency_ms","active_tracks","occluded_tracks",
                       "persons","vehicles","signs","lane_segments"])

        frame_id = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame_id += 1
            start = time.perf_counter()

            frame = undistort(frame, calib)
            detections = detector.detect(frame)
            tracks = mark_occlusions(tracker.update(detections))
            signs = sign_rec.detect(frame)
            lane_frame, segments = detect_road_markings(
                frame,
                cfg["lane"]["canny_low"],
                cfg["lane"]["canny_high"],
                cfg["lane"]["roi_top_ratio"]
            )

            persons = sum(d["label"] == "person" for d in detections)
            vehicles = sum(d["label"] in {"car","bus","truck","motorcycle","bicycle"} for d in detections)

            for t in tracks:
                color = (0, 165, 255) if t.get("occluded") else (0, 255, 0)
                draw_detection(lane_frame, t, color, f'ID {t["track_id"]} ')
                if t.get("occluded"):
                    x1,y1,x2,y2 = t["bbox"]
                    cv2.putText(lane_frame, "OCCLUDED",
                                (x1, min(height-10,y2+18)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

            for s in signs:
                draw_detection(lane_frame, s, (255,0,255), "SIGN ")

            latency_ms = (time.perf_counter() - start) * 1000
            cv2.rectangle(lane_frame, (10,10), (430,110), (0,0,0), -1)
            cv2.putText(lane_frame, f"Frame: {frame_id}", (20,35),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255,255,255), 2)
            cv2.putText(lane_frame, f"Latency: {latency_ms:.1f} ms", (20,62),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255,255,255), 2)
            cv2.putText(lane_frame, f"People: {persons} Vehicles: {vehicles}", (20,89),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255,255,255), 2)

            writer.write(lane_frame)
            log.writerow([frame_id, round(latency_ms,3), len(tracks),
                          sum(t.get("occluded",False) for t in tracks),
                          persons, vehicles, len(signs), len(segments)])

            cv2.imshow("Autonomous Road Safety System", lane_frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    cap.release()
    writer.release()
    cv2.destroyAllWindows()
    print(f"Annotated video: {args.output}")
    print(f"Metrics CSV:     {csv_path}")

if __name__ == "__main__":
    main()
