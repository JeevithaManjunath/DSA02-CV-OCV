import cv2
import numpy as np

def detect_road_markings(frame, canny_low=50, canny_high=150, roi_top_ratio=0.55):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, canny_low, canny_high)

    h, w = edges.shape
    mask = np.zeros_like(edges)
    polygon = np.array([[
        (int(0.05*w), h),
        (int(0.45*w), int(roi_top_ratio*h)),
        (int(0.55*w), int(roi_top_ratio*h)),
        (int(0.95*w), h)
    ]], dtype=np.int32)
    cv2.fillPoly(mask, polygon, 255)
    roi = cv2.bitwise_and(edges, mask)

    lines = cv2.HoughLinesP(roi, 1, np.pi/180, threshold=40,
                            minLineLength=40, maxLineGap=100)
    output = frame.copy()
    segments = []
    if lines is not None:
        for l in lines[:, 0]:
            x1, y1, x2, y2 = map(int, l)
            segments.append((x1, y1, x2, y2))
            cv2.line(output, (x1, y1), (x2, y2), (255, 200, 0), 3)
    return output, segments
