Generated annotated videos and CSV metrics will be saved here.
